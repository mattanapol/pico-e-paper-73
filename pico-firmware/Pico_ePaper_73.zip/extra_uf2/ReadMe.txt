Mode selection:
	Mode 0: automatically get PIC and sorted the name of the folder pictures
	Mode 1: Automatically get pic folder names but not sorted
	Mode 2: don't automatically get PIC folder in the name of the images, the user needs to himself in the TF card created under the root directory of the fileList. TXT file and write images in the file name





Clock selection (the next timer will start only after the screen refresh is complete) :
	rtc_15_minutes.uf2: Refresh every fifteen minutes
	rtc_30_minutes.uf2: Refresh every thirty minutes
	rtc_1_hours.uf2: Refresh once an hour
	rtc_2_hours.uf2: Refresh every two hours
	rtc_4_hours.uf2: Refresh every four hours
	rtc_6_hours.uf2: Refresh every six hours
	rtc_8_hours.uf2: Refresh every eight hours
	rtc_10_hours.uf2: Refresh every ten hours
	rtc_12_hours.uf2: Refresh every twelve hours
	rtc_24_hours.uf2: Refresh every 24 hours
